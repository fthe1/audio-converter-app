package com.franco.audioconverter

import android.app.Application
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.annotation.OptIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class VideoInfo(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val hasAudio: Boolean,
    val thumb: ImageBitmap?,
)

sealed interface ConvertState {
    data object Idle : ConvertState
    data class Running(val progress: Int) : ConvertState
    data class Done(val fileName: String) : ConvertState
    data class Failed(val message: String) : ConvertState
}

@OptIn(UnstableApi::class)
class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val store = AudioStore(app)

    var video by mutableStateOf<VideoInfo?>(null); private set
    var loadingVideo by mutableStateOf(false); private set
    var fileName by mutableStateOf("")
    var state by mutableStateOf<ConvertState>(ConvertState.Idle); private set
    val files = mutableStateListOf<AudioItem>()

    /** True right after a successful conversion; the UI shows one ad and clears it. */
    var pendingAd by mutableStateOf(false)

    var playingUri by mutableStateOf<Uri?>(null); private set
    var playProgress by mutableFloatStateOf(0f); private set

    private var transformer: Transformer? = null
    private var tempFile: File? = null
    private var progressJob: Job? = null
    private var player: MediaPlayer? = null
    private var playerJob: Job? = null

    init { refresh() }

    // ---------- Video ----------

    fun onVideoPicked(uri: Uri) {
        if (state is ConvertState.Running) return
        state = ConvertState.Idle
        loadingVideo = true
        viewModelScope.launch {
            val info = withContext(Dispatchers.IO) { readVideo(uri) }
            loadingVideo = false
            if (info == null) {
                state = ConvertState.Failed("تعذّر قراءة هذا الفيديو")
                return@launch
            }
            video = info
            fileName = info.name.substringBeforeLast('.').take(80)
        }
    }

    private fun readVideo(uri: Uri): VideoInfo? = runCatching {
        var name = "video"
        var size = 0L
        app.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
            ?.use { c ->
                if (c.moveToFirst()) {
                    c.getString(0)?.let { name = it }
                    if (!c.isNull(1)) size = c.getLong(1)
                }
            }
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(app, uri)
            val dur = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val hasAudio = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            val thumb = runCatching {
                m.getFrameAtTime(minOf(1_000_000L, dur * 500), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?.let { scale(it) }?.asImageBitmap()
            }.getOrNull()
            VideoInfo(uri, name, dur, size, hasAudio, thumb)
        } finally {
            m.release()
        }
    }.getOrNull()

    private fun scale(b: Bitmap): Bitmap {
        val max = 240
        val s = max.toFloat() / maxOf(b.width, b.height)
        return if (s >= 1f) b else Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
    }

    // ---------- Convert ----------

    fun convert() {
        val v = video ?: return
        if (state is ConvertState.Running) return
        val base = fileName.replace(Regex("[\\\\/:*?\"<>|\\n]"), "_").trim().trim('.')
            .ifBlank { "audio_${System.currentTimeMillis()}" }
        val tmp = File(app.cacheDir, "export_${System.currentTimeMillis()}.m4a")
        tempFile = tmp
        state = ConvertState.Running(0)

        val t = Transformer.Builder(app)
            .setAudioMimeType(MimeTypes.AUDIO_AAC) // AAC in .m4a – plays everywhere
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onExportDone(tmp, base)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    stopProgress()
                    tmp.delete()
                    state = ConvertState.Failed("فشل التحويل، جرّب فيديو آخر")
                }
            })
            .build()
        transformer = t

        val item = EditedMediaItem.Builder(MediaItem.fromUri(v.uri)).setRemoveVideo(true).build()
        try {
            t.start(item, tmp.absolutePath)
        } catch (e: Exception) {
            state = ConvertState.Failed("فشل التحويل، جرّب فيديو آخر")
            return
        }

        progressJob = viewModelScope.launch {
            val holder = ProgressHolder()
            while (isActive) {
                if (t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE &&
                    state is ConvertState.Running
                ) state = ConvertState.Running(holder.progress)
                delay(150)
            }
        }
    }

    private fun onExportDone(tmp: File, base: String) {
        stopProgress()
        state = ConvertState.Running(100)
        viewModelScope.launch {
            val saved = runCatching { withContext(Dispatchers.IO) { store.save(tmp, base) } }
            tmp.delete()
            state = saved.fold(
                onSuccess = { ConvertState.Done(it) },
                onFailure = { ConvertState.Failed("تعذّر حفظ الملف") },
            )
            if (saved.isSuccess) pendingAd = true
            refresh()
        }
    }

    fun cancel() {
        transformer?.cancel()
        stopProgress()
        tempFile?.delete()
        state = ConvertState.Idle
    }

    fun reset() {
        video = null
        fileName = ""
        state = ConvertState.Idle
    }

    private fun stopProgress() {
        progressJob?.cancel()
        progressJob = null
        transformer = null
    }

    // ---------- Files ----------

    fun refresh() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { runCatching { store.list() }.getOrDefault(emptyList()) }
            files.clear()
            files.addAll(list)
        }
    }

    fun delete(item: AudioItem) {
        if (playingUri == item.uri) stopPlayback()
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { store.delete(item) } }
            refresh()
        }
    }

    fun togglePlay(item: AudioItem) {
        if (playingUri == item.uri) {
            stopPlayback()
            return
        }
        stopPlayback()
        val p = MediaPlayer()
        try {
            p.setDataSource(app, item.uri)
            p.setOnCompletionListener { stopPlayback() }
            p.prepare()
            p.start()
        } catch (e: Exception) {
            p.release()
            return
        }
        player = p
        playingUri = item.uri
        playerJob = viewModelScope.launch {
            while (isActive) {
                val d = p.duration
                playProgress = if (d > 0) p.currentPosition.toFloat() / d else 0f
                delay(200)
            }
        }
    }

    fun stopPlayback() {
        playerJob?.cancel()
        playerJob = null
        player?.release()
        player = null
        playingUri = null
        playProgress = 0f
    }

    override fun onCleared() {
        transformer?.cancel()
        tempFile?.delete()
        stopPlayback()
    }
}
