# محول الصوت — Audio Converter

تطبيق Android خفيف لاستخراج الصوت من الفيديو وحفظه بصيغة M4A (AAC).

- Kotlin + Jetpack Compose (Material 3) — دعم كامل للعربية والوضع الليلي.
- الاستخراج عبر Media3 Transformer: سريع جدًا (نسخ مباشر للصوت دون إعادة ترميز إن كان AAC).
- بدون أي صلاحيات: اختيار الفيديو عبر Photo Picker، والحفظ في `Music/Audio Converter` (Android 10+).
- minSdk 24 (Android 7) · targetSdk 35.

## الحصول على APK
**الطريقة 1 – GitHub (بدون تثبيت أي شيء):** ارفع المجلد إلى مستودع جديد ← تبويب Actions ← آخر تشغيل لـ «Build APK» ← نزّل `AudioConverter-APK`.

**الطريقة 2 – Android Studio:** افتح المجلد ← Build ← Build APK(s).

> نسخة الإصدار موقّعة بمفتاح debug للتثبيت المباشر. للنشر على Google Play استبدله بمفتاحك الخاص في `app/build.gradle.kts`.
