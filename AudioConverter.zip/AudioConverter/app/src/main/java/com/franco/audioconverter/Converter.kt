package com.franco.audioconverter

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.math.log2
import kotlin.math.min

class NoAudioException : Exception("no audio track")
class CancelledException : Exception("cancelled")

/**
 * Video → audio. Decodes the first audio track to 16-bit PCM and streams it into the chosen encoder,
 * so no large temporary file is ever written.
 */
object Converter {

    fun convert(
        ctx: Context,
        uri: Uri,
        format: OutFormat,
        kbps: Int,
        dst: File,
        progress: (Float) -> Unit,
        isCancelled: () -> Boolean,
    ) {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var track = -1
        for (i in 0 until ex.trackCount) {
            if (ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
        }
        if (track < 0) { ex.release(); throw NoAudioException() }
        ex.selectTrack(track)
        val inFmt = ex.getTrackFormat(track)
        val mime = inFmt.getString(MediaFormat.KEY_MIME)!!
        val durUs = if (inFmt.containsKey(MediaFormat.KEY_DURATION)) inFmt.getLong(MediaFormat.KEY_DURATION) else 0L

        val dec = MediaCodec.createDecoderByType(mime)
        var sink: PcmSink? = null
        var ok = false
        try {
            dec.configure(inFmt, null, null, 0)
            dec.start()
            var rate = inFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = inFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var isFloat = false
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var totalFrames = 0L
            var idle = 0

            while (!outDone) {
                if (isCancelled()) throw CancelledException()
                if (!inDone) {
                    val i = dec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = dec.getInputBuffer(i)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            dec.queueInputBuffer(i, 0, n, ex.sampleTime.coerceAtLeast(0), 0)
                            ex.advance()
                        }
                    }
                }
                val o = dec.dequeueOutputBuffer(info, 10_000)
                when {
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = dec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        isFloat = f.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            f.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                    o >= 0 -> {
                        idle = 0
                        if (info.size > 0 && ch > 0) {
                            val buf = dec.getOutputBuffer(o)!!
                            buf.position(info.offset); buf.limit(info.offset + info.size)
                            val outCh = min(ch, 2)
                            val pcm = toPcm16(buf.slice().order(ByteOrder.nativeOrder()), ch, outCh, isFloat)
                            val frames = pcm.size / outCh
                            if (frames > 0) {
                                val s = sink ?: createSink(format, dst, rate, outCh, kbps).also { sink = it }
                                s.write(pcm, frames)
                                totalFrames += frames
                            }
                            if (durUs > 0) progress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 0.99f))
                        }
                        dec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                    }
                    o == MediaCodec.INFO_TRY_AGAIN_LATER && inDone -> {
                        // Guard against decoders that never signal end of stream.
                        if (++idle > 300) outDone = true
                    }
                }
            }
            if (totalFrames == 0L || sink == null) throw NoAudioException()
            sink!!.finish()
            ok = true
            progress(1f)
        } finally {
            if (!ok) runCatching { sink?.abort() }
            runCatching { dec.stop() }
            dec.release()
            ex.release()
            if (!ok) dst.delete()
        }
    }

    /** Interleaved PCM (16-bit or float, any channel count) → interleaved 16-bit with at most 2 channels. */
    private fun toPcm16(buf: java.nio.ByteBuffer, ch: Int, outCh: Int, isFloat: Boolean): ShortArray {
        if (isFloat) {
            val fb = buf.asFloatBuffer()
            val frames = fb.remaining() / ch
            val out = ShortArray(frames * outCh)
            var o = 0
            for (f in 0 until frames) for (c in 0 until ch) {
                val v = fb.get()
                if (c < outCh) out[o++] = (v.coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            }
            return out
        }
        val sb = buf.asShortBuffer()
        val frames = sb.remaining() / ch
        val out = ShortArray(frames * outCh)
        if (ch == outCh) { sb.get(out, 0, frames * ch); return out }
        var o = 0
        for (f in 0 until frames) for (c in 0 until ch) {
            val v = sb.get()
            if (c < outCh) out[o++] = v
        }
        return out
    }

    private fun createSink(format: OutFormat, dst: File, rate: Int, ch: Int, kbps: Int): PcmSink = when (format) {
        OutFormat.WAV -> PcmFileSink(dst, rate, ch, bigEndian = false)
        OutFormat.AIFF -> PcmFileSink(dst, rate, ch, bigEndian = true)
        OutFormat.FLAC -> FlacSink(dst, rate, ch)
        OutFormat.M4A -> CodecSink(dst, MediaFormat.MIMETYPE_AUDIO_AAC, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4,
            if (rate in AAC_RATES) rate else 48000, rate, ch, kbps)
        // OGG is only offered on Android 10+ (see OutFormat.isAvailable).
        OutFormat.OGG -> CodecSink(dst, MediaFormat.MIMETYPE_AUDIO_OPUS, MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG,
            48000, rate, ch, kbps)
    }

    private val AAC_RATES = setOf(8000, 11025, 12000, 16000, 22050, 24000, 32000, 44100, 48000)
}

/* ============================== sinks ============================== */

interface PcmSink {
    fun write(pcm: ShortArray, frames: Int)
    fun finish()
    fun abort()
}

/** WAV (little-endian) or AIFF (big-endian). Sizes are patched into the header at the end. */
class PcmFileSink(private val file: File, private val rate: Int, private val ch: Int, private val bigEndian: Boolean) : PcmSink {
    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
    private var frames = 0L
    private val headerSize = if (bigEndian) 54 else 44

    init { out.write(ByteArray(headerSize)) }

    override fun write(pcm: ShortArray, frames: Int) {
        val n = frames * ch
        val bytes = ByteArray(n * 2)
        var o = 0
        for (i in 0 until n) {
            val v = pcm[i].toInt()
            if (bigEndian) { bytes[o++] = (v shr 8).toByte(); bytes[o++] = v.toByte() }
            else { bytes[o++] = v.toByte(); bytes[o++] = (v shr 8).toByte() }
        }
        out.write(bytes)
        this.frames += frames
    }

    override fun finish() {
        out.close()
        val dataLen = (frames * ch * 2).coerceAtMost(0xFFFFFFF0L)
        val h = java.nio.ByteBuffer.allocate(headerSize)
        if (!bigEndian) {
            h.order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).toInt()); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(ch.toShort()); h.putInt(rate)
            h.putInt(rate * ch * 2); h.putShort((ch * 2).toShort()); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataLen.toInt())
        } else {
            h.order(ByteOrder.BIG_ENDIAN)
            h.put("FORM".toByteArray()); h.putInt((46 + dataLen).toInt()); h.put("AIFF".toByteArray())
            h.put("COMM".toByteArray()); h.putInt(18); h.putShort(ch.toShort()); h.putInt(frames.toInt()); h.putShort(16)
            val e = floor(log2(rate.toDouble())).toInt()
            h.putShort((16383 + e).toShort()); h.putInt((rate.toLong() shl (31 - e)).toInt()); h.putInt(0)
            h.put("SSND".toByteArray()); h.putInt((8 + dataLen).toInt()); h.putInt(0); h.putInt(0)
        }
        RandomAccessFile(file, "rw").use { it.seek(0); it.write(h.array()) }
    }

    override fun abort() { runCatching { out.close() } }
}

/** Lossless FLAC with fixed predictors (order 0–4) and Rice-coded residuals. */
class FlacSink(private val file: File, private val rate: Int, private val ch: Int) : PcmSink {
    private val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
    private val bs = 4096
    private val block = Array(ch) { IntArray(bs) }
    private var fill = 0
    private var frameNo = 0
    private var total = 0L
    private val w = Bits(bs * ch * 4 + 64)

    init { out.write(streamInfo(0)) }

    override fun write(pcm: ShortArray, frames: Int) {
        var i = 0
        while (i < frames) {
            for (c in 0 until ch) block[c][fill] = pcm[i * ch + c].toInt()
            fill++; i++
            if (fill == bs) flushBlock()
        }
        total += frames
    }

    override fun finish() {
        if (fill > 0) flushBlock()
        out.close()
        RandomAccessFile(file, "rw").use { it.seek(0); it.write(streamInfo(total)) }
    }

    override fun abort() { runCatching { out.close() } }

    private fun streamInfo(samples: Long): ByteArray {
        val b = Bits(64)
        "fLaC".forEach { b.w(it.code, 8) }
        b.w(0x80, 8); b.w(34, 24)
        b.w(bs, 16); b.w(bs, 16); b.w(0, 24); b.w(0, 24)
        b.w(rate shr 4, 16); b.w(rate and 15, 4); b.w(ch - 1, 3); b.w(15, 5)
        b.w(((samples shr 32) and 15).toInt(), 4); b.w(((samples shr 16) and 0xFFFF).toInt(), 16); b.w((samples and 0xFFFF).toInt(), 16)
        repeat(16) { b.w(0, 8) }
        return b.bytes()
    }

    private fun flushBlock() {
        val n = fill
        w.reset()
        w.w(0xFFF8, 16); w.w(7, 4); w.w(0, 4); w.w(ch - 1, 4); w.w(4, 3); w.w(0, 1)
        utf8(frameNo); w.w(n - 1, 16)
        w.w(crc8(w.buf, w.pos), 8)
        for (c in 0 until ch) subframe(block[c], n)
        w.align()
        w.w(crc16(w.buf, w.pos), 16)
        out.write(w.buf, 0, w.pos)
        frameNo++
        fill = 0
    }

    private fun utf8(v: Int) {
        when {
            v < 0x80 -> w.w(v, 8)
            v < 0x800 -> { w.w(0xC0 or (v shr 6), 8); w.w(0x80 or (v and 0x3F), 8) }
            v < 0x10000 -> { w.w(0xE0 or (v shr 12), 8); w.w(0x80 or ((v shr 6) and 0x3F), 8); w.w(0x80 or (v and 0x3F), 8) }
            else -> { w.w(0xF0 or (v shr 18), 8); w.w(0x80 or ((v shr 12) and 0x3F), 8); w.w(0x80 or ((v shr 6) and 0x3F), 8); w.w(0x80 or (v and 0x3F), 8) }
        }
    }

    private fun residual(x: IntArray, i: Int, o: Int): Int = when (o) {
        0 -> x[i]
        1 -> x[i] - x[i - 1]
        2 -> x[i] - 2 * x[i - 1] + x[i - 2]
        3 -> x[i] - 3 * x[i - 1] + 3 * x[i - 2] - x[i - 3]
        else -> x[i] - 4 * x[i - 1] + 6 * x[i - 2] - 4 * x[i - 3] + x[i - 4]
    }

    private fun subframe(x: IntArray, n: Int) {
        var best = 0
        var bestSum = Long.MAX_VALUE
        for (o in 0..min(4, n - 1)) {
            var s = 0L
            for (i in o until n) s += kotlin.math.abs(residual(x, i, o))
            if (s < bestSum) { bestSum = s; best = o }
        }
        w.w(0, 1); w.w(8 or best, 6); w.w(0, 1)
        for (i in 0 until best) w.w(x[i] and 0xFFFF, 16)
        val cnt = n - best
        val mean = if (cnt > 0) bestSum.toDouble() / cnt else 0.0
        val k = if (mean > 0) (floor(log2(mean * 2 + 1)).toInt() - 1).coerceIn(0, 14) else 0
        w.w(0, 2); w.w(0, 4); w.w(k, 4)
        val mask = (1 shl k) - 1
        for (i in best until n) {
            val r = residual(x, i, best)
            val u = if (r >= 0) 2 * r else -2 * r - 1
            w.unary(u ushr k)
            if (k > 0) w.w(u and mask, k)
        }
    }

    private class Bits(size: Int) {
        var buf = ByteArray(size); var pos = 0
        private var acc = 0; private var n = 0
        fun reset() { pos = 0; acc = 0; n = 0 }
        fun w(v: Int, bits: Int) { // bits <= 24
            if (pos + 8 >= buf.size) buf = buf.copyOf(buf.size * 2)
            acc = (acc shl bits) or (v and ((1 shl bits) - 1)); n += bits
            while (n >= 8) { n -= 8; buf[pos++] = (acc ushr n).toByte() }
            acc = acc and ((1 shl n) - 1)
        }
        fun unary(q0: Int) { var q = q0; while (q >= 24) { w(0, 24); q -= 24 }; w(1, q + 1) }
        fun align() { if (n > 0) w(0, 8 - n) }
        fun bytes(): ByteArray = buf.copyOf(pos)
    }

    companion object {
        private val CRC8 = IntArray(256).also { t -> for (i in 0 until 256) { var c = i; repeat(8) { c = if (c and 0x80 != 0) ((c shl 1) xor 0x07) and 0xFF else (c shl 1) and 0xFF }; t[i] = c } }
        private val CRC16 = IntArray(256).also { t -> for (i in 0 until 256) { var c = i shl 8; repeat(8) { c = if (c and 0x8000 != 0) ((c shl 1) xor 0x8005) and 0xFFFF else (c shl 1) and 0xFFFF }; t[i] = c } }
        private fun crc8(b: ByteArray, n: Int): Int { var c = 0; for (i in 0 until n) c = CRC8[c xor (b[i].toInt() and 0xFF)]; return c }
        private fun crc16(b: ByteArray, n: Int): Int { var c = 0; for (i in 0 until n) c = ((c shl 8) and 0xFFFF) xor CRC16[(c shr 8) xor (b[i].toInt() and 0xFF)]; return c }
    }
}

/** AAC (M4A) or Opus (OGG) through the phone's own encoder and muxer. */
class CodecSink(
    private val file: File,
    mime: String,
    muxerFormat: Int,
    private val outRate: Int,
    inRate: Int,
    private val ch: Int,
    kbps: Int,
) : PcmSink {
    private val enc = MediaCodec.createEncoderByType(mime)
    private val mux = MediaMuxer(file.absolutePath, muxerFormat)
    private val resampler = if (inRate != outRate) Resampler(ch, inRate, outRate) else null
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false
    private var framesIn = 0L
    private val frameBytes = ch * 2

    init {
        val fmt = MediaFormat.createAudioFormat(mime, outRate, ch).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, min(kbps, 256 * ch) * 1000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        }
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
        } catch (e: Exception) {
            enc.release(); mux.release(); throw e
        }
    }

    override fun write(pcm: ShortArray, frames: Int) {
        val data = resampler?.process(pcm, frames) ?: pcm.copyOf(frames * ch)
        val bytes = ByteArray(data.size * 2)
        java.nio.ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(data)
        var off = 0
        while (off < bytes.size) {
            val i = enc.dequeueInputBuffer(10_000)
            if (i < 0) { drain(false); continue }
            val b = enc.getInputBuffer(i)!!
            b.clear()
            var n = min(b.remaining(), bytes.size - off)
            n -= n % frameBytes
            if (n <= 0) n = min(frameBytes, bytes.size - off)
            b.put(bytes, off, n)
            enc.queueInputBuffer(i, 0, n, framesIn * 1_000_000L / outRate, 0)
            framesIn += n / frameBytes
            off += n
            drain(false)
        }
    }

    override fun finish() {
        var queued = false
        var tries = 0
        while (!queued && tries++ < 500) {
            val i = enc.dequeueInputBuffer(10_000)
            if (i >= 0) {
                enc.queueInputBuffer(i, 0, 0, framesIn * 1_000_000L / outRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                queued = true
            } else drain(false)
        }
        drain(true)
        runCatching { enc.stop() }
        enc.release()
        if (started) mux.stop()
        mux.release()
        if (!started) throw IllegalStateException("encoder produced no output")
    }

    override fun abort() {
        runCatching { enc.stop() }; runCatching { enc.release() }
        runCatching { if (started) mux.stop() }; runCatching { mux.release() }
    }

    private fun drain(untilEos: Boolean) {
        var idle = 0
        while (true) {
            val o = enc.dequeueOutputBuffer(info, if (untilEos) 10_000 else 0)
            when {
                o == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (!untilEos || ++idle > 300) return }
                o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!started) { track = mux.addTrack(enc.outputFormat); mux.start(); started = true }
                }
                o >= 0 -> {
                    idle = 0
                    val b = enc.getOutputBuffer(o)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0 && started) {
                        b.position(info.offset); b.limit(info.offset + info.size)
                        mux.writeSampleData(track, b, info)
                    }
                    enc.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }
}

/** Streaming linear resampler for interleaved 16-bit PCM. */
class Resampler(private val ch: Int, inRate: Int, outRate: Int) {
    private val step = inRate.toDouble() / outRate
    private var t = 0.0
    private val last = IntArray(ch)
    private var hasLast = false

    fun process(inp: ShortArray, frames: Int): ShortArray {
        val len = frames + if (hasLast) 1 else 0
        if (len < 2) {
            if (frames > 0) { for (c in 0 until ch) last[c] = inp[(frames - 1) * ch + c].toInt(); hasLast = true }
            return ShortArray(0)
        }
        fun at(i: Int, c: Int): Int = if (hasLast) (if (i == 0) last[c] else inp[(i - 1) * ch + c].toInt()) else inp[i * ch + c].toInt()
        val est = ((len - t) / step).toInt() + 2
        val out = ShortArray(est * ch)
        var o = 0
        var pos = t
        while (pos <= len - 1 - 1e-9 && o + ch <= out.size) {
            val i = pos.toInt()
            val f = pos - i
            for (c in 0 until ch) {
                val a = at(i, c)
                val b = at(min(i + 1, len - 1), c)
                out[o++] = (a + (b - a) * f).toInt().coerceIn(-32768, 32767).toShort()
            }
            pos += step
        }
        t = pos - (len - 1)
        for (c in 0 until ch) last[c] = at(len - 1, c)
        hasLast = true
        return if (o == out.size) out else out.copyOf(o)
    }
}
