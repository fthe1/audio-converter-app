package com.franco.audioconverter

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File

data class AudioItem(
    val uri: Uri,
    val shareUri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateMs: Long,
    val file: File? = null,
)

/**
 * Android 10+: saves into the public Music/Audio Converter folder (visible to every music player, no permission).
 * Android 7–9: saves into the app's own Music folder (no permission needed).
 */
class AudioStore(private val ctx: Context) {
    private val folder = "Audio Converter"
    private val relPath = "${Environment.DIRECTORY_MUSIC}/$folder/"
    private val legacyDir: File
        get() = File(ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC), folder).apply { mkdirs() }

    fun save(src: File, baseName: String): String {
        val display = "$baseName.m4a"
        if (Build.VERSION.SDK_INT >= 29) {
            val r = ctx.contentResolver
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, display)
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = r.insert(collection, values) ?: error("insert failed")
            try {
                r.openOutputStream(uri)!!.use { out -> src.inputStream().use { it.copyTo(out) } }
                r.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) {
                r.delete(uri, null, null)
                throw e
            }
            r.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
            return display
        } else {
            var f = File(legacyDir, display)
            var i = 1
            while (f.exists()) f = File(legacyDir, "$baseName (${i++}).m4a")
            src.copyTo(f)
            return f.name
        }
    }

    fun list(): List<AudioItem> {
        if (Build.VERSION.SDK_INT >= 29) {
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val proj = arrayOf(
                MediaStore.MediaColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DURATION,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_ADDED,
            )
            val out = ArrayList<AudioItem>()
            ctx.contentResolver.query(
                collection, proj,
                "${MediaStore.MediaColumns.RELATIVE_PATH} = ?", arrayOf(relPath),
                "${MediaStore.MediaColumns.DATE_ADDED} DESC",
            )?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(collection, c.getLong(0))
                    var dur = c.getLong(2)
                    if (dur <= 0) dur = durationOf(uri)
                    out += AudioItem(uri, uri, c.getString(1), dur, c.getLong(3), c.getLong(4) * 1000)
                }
            }
            return out
        } else {
            return (legacyDir.listFiles { f -> f.extension.equals("m4a", true) } ?: emptyArray())
                .sortedByDescending { it.lastModified() }
                .map { f ->
                    val uri = Uri.fromFile(f)
                    AudioItem(
                        uri = uri,
                        shareUri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f),
                        name = f.name,
                        durationMs = durationOf(uri),
                        sizeBytes = f.length(),
                        dateMs = f.lastModified(),
                        file = f,
                    )
                }
        }
    }

    fun delete(item: AudioItem) {
        if (item.file != null) item.file.delete()
        else ctx.contentResolver.delete(item.uri, null, null)
    }

    private fun durationOf(uri: Uri): Long = runCatching {
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(ctx, uri)
            m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            m.release()
        }
    }.getOrDefault(0L)
}
