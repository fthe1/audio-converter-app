package com.franco.audioconverter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: MainViewModel, pad: PaddingValues, onOpenDoc: (String) -> Unit) {
    val ctx = LocalContext.current
    val activity = ctx as? Activity
    val version = runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0"
    var dialog by remember { mutableStateOf<String?>(null) }
    val openUrl = { url: String -> runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }; Unit }

    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Header("الإعدادات", "الصيغة، المساعدة، والمعلومات القانونية")

        Group("التحويل") {
            ValueRow("الصيغة الافتراضية", "${vm.format.label} · ${vm.format.subtitle}") { dialog = "format" }
            Divider()
            ValueRow("الجودة الافتراضية", if (vm.format.lossy) "${vm.kbps} kbps" else "أصلية (بدون فقد)") { dialog = "quality" }
        }

        Group("المساعدة") {
            LinkRow("طريقة الاستخدام") { onOpenDoc("howto") }
        }

        Group("موقعنا") {
            LinkRow("FRANCO GAMES — ألعابنا وتطبيقاتنا", Icons.AutoMirrored.Rounded.OpenInNew) { openUrl(Legal.SITE_URL) }
        }

        Group("قانوني") {
            LinkRow("سياسة الخصوصية") { onOpenDoc("privacy") }
            Divider()
            LinkRow("شروط الاستخدام") { onOpenDoc("terms") }
        }

        if (Ads.privacyOptionsRequired(ctx)) {
            Group("الإعلانات") {
                LinkRow("خيارات الخصوصية الإعلانية") { activity?.let { Ads.showPrivacyOptions(it) } }
            }
        }

        Group("حول التطبيق") {
            InfoRow("الإصدار", version)
            Divider()
            InfoRow("المطوّر", "Franco")
            Divider()
            InfoRow("الصيغ المتاحة", OutFormat.available.joinToString(" · ") { it.label })
        }

        Text(
            "كل المعالجة تتم على هاتفك، ولا يُرفع أي ملف.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
        )
    }

    when (dialog) {
        "format" -> ChoiceDialog(
            title = "الصيغة الافتراضية",
            options = OutFormat.available.map { it.id to "${it.label} — ${it.subtitle}" },
            selected = vm.format.id,
            onPick = { id -> vm.setDefaultFormat(OutFormat.of(id)); dialog = null },
            onDismiss = { dialog = null },
        )
        "quality" -> ChoiceDialog(
            title = "الجودة الافتراضية (M4A و OGG)",
            options = OutFormat.QUALITIES.map { it.toString() to "$it kbps" + when (it) { 128 -> " · حجم أصغر"; 320 -> " · أعلى جودة"; else -> " · متوازن" } },
            selected = vm.kbps.toString(),
            onPick = { q -> vm.setDefaultQuality(q.toInt()); dialog = null },
            onDismiss = { dialog = null },
        )
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (id, label) ->
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable { onPick(id) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(selected = id == selected, onClick = { onPick(id) })
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
    )
}

@Composable
fun DocScreen(id: String, pad: PaddingValues, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val (title, sections, url) = when (id) {
        "terms" -> Triple("شروط الاستخدام", Legal.terms, Legal.TERMS_URL)
        "howto" -> Triple("طريقة الاستخدام", Legal.howTo, "")
        else -> Triple("سياسة الخصوصية", Legal.privacy, Legal.POLICY_URL)
    }

    Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
            Spacer(Modifier.padding(start = 6.dp))
            Text("رجوع")
        }
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                sections.forEachIndexed { i, (h, body) ->
                    if (i > 0) Spacer(Modifier.height(8.dp))
                    Text(h, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (url.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(Legal.UPDATED, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (url.isNotEmpty()) {
            TextButton(
                onClick = { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } },
                modifier = Modifier.padding(vertical = 8.dp),
            ) {
                Text("فتح النسخة على الويب")
                Spacer(Modifier.padding(start = 6.dp))
                Icon(Icons.AutoMirrored.Rounded.OpenInNew, null)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 8.dp, start = 4.dp),
    )
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) { Column { content() } }
}

@Composable
private fun Divider() = HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

@Composable
private fun LinkRow(label: String, icon: ImageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).clickable(onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ValueRow(label: String, value: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyLarge)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
