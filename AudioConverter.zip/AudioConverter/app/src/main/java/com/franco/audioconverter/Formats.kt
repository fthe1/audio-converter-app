package com.franco.audioconverter

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build

/** Output formats the app can create. MP3 is absent: Android has no built-in MP3 encoder. */
enum class OutFormat(
    val id: String,
    val label: String,
    val ext: String,
    val mime: String,
    val lossy: Boolean,
    val subtitle: String,
) {
    M4A("m4a", "M4A", "m4a", "audio/mp4", true, "AAC · الأكثر توافقًا"),
    OGG("ogg", "OGG", "ogg", "audio/ogg", true, "Opus · أصغر حجم"),
    WAV("wav", "WAV", "wav", "audio/x-wav", false, "بدون ضغط"),
    FLAC("flac", "FLAC", "flac", "audio/flac", false, "بدون فقد · مضغوط"),
    AIFF("aiff", "AIFF", "aiff", "audio/x-aiff", false, "بدون ضغط · Apple");

    val isAvailable: Boolean by lazy {
        when (this) {
            M4A -> hasEncoder(MediaFormat.MIMETYPE_AUDIO_AAC)
            OGG -> Build.VERSION.SDK_INT >= 29 && hasEncoder(MediaFormat.MIMETYPE_AUDIO_OPUS)
            else -> true
        }
    }

    companion object {
        fun of(id: String?): OutFormat = entries.firstOrNull { it.id == id && it.isAvailable } ?: M4A
        fun byExt(ext: String): OutFormat? = entries.firstOrNull { it.ext.equals(ext, true) || (it == AIFF && ext.equals("aif", true)) }
        val available: List<OutFormat> get() = entries.filter { it.isAvailable }
        val QUALITIES = listOf(128, 192, 320)

        private fun hasEncoder(mime: String): Boolean = runCatching {
            MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(mime, ignoreCase = true) }
            }
        }.getOrDefault(false)
    }
}

/** Small persisted settings. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var format: OutFormat
        get() = OutFormat.of(sp.getString("format", OutFormat.M4A.id))
        set(v) = sp.edit().putString("format", v.id).apply()
    var kbps: Int
        get() = sp.getInt("kbps", 192).let { if (it in OutFormat.QUALITIES) it else 192 }
        set(v) = sp.edit().putInt("kbps", v).apply()
}
