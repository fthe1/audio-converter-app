package com.franco.audioconverter

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

/**
 * One interstitial ad after every successful conversion.
 * Interstitial unit: after_convert_interstitial.
 */
object Ads {
    private const val INTERSTITIAL_ID = "ca-app-pub-4793101120321816/1742363940"

    private val started = AtomicBoolean(false)
    private var ad: InterstitialAd? = null
    private var loading = false

    /** Ask for consent where the law requires it (EEA/UK), then start the ads SDK. Call once from onCreate. */
    fun setup(activity: Activity) {
        val consent = UserMessagingPlatform.getConsentInformation(activity)
        consent.requestConsentInfoUpdate(
            activity,
            ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(activity) {
                    if (consent.canRequestAds()) start(activity)
                }
            },
            { if (consent.canRequestAds()) start(activity) },
        )
        if (consent.canRequestAds()) start(activity)
    }

    /** True where the user must be able to change their ad consent (EEA/UK/CH). */
    fun privacyOptionsRequired(ctx: Context): Boolean =
        UserMessagingPlatform.getConsentInformation(ctx).privacyOptionsRequirementStatus ==
            ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED

    fun showPrivacyOptions(activity: Activity) {
        UserMessagingPlatform.showPrivacyOptionsForm(activity) { }
    }

    private fun start(activity: Activity) {
        if (started.getAndSet(true)) return
        val app = activity.applicationContext
        Thread {
            MobileAds.initialize(app) {}
            activity.runOnUiThread { load(app) }
        }.start()
    }

    private fun load(ctx: Context) {
        if (!started.get() || loading || ad != null) return
        loading = true
        InterstitialAd.load(ctx, INTERSTITIAL_ID, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(loaded: InterstitialAd) {
                ad = loaded
                loading = false
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                ad = null
                loading = false
            }
        })
    }

    /** Show the ad if one is ready; never blocks the user when it isn't. */
    fun show(activity: Activity) {
        val ctx = activity.applicationContext
        val current = ad ?: run { load(ctx); return }
        ad = null
        current.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() = load(ctx)
            override fun onAdFailedToShowFullScreenContent(error: AdError) = load(ctx)
        }
        current.show(activity)
    }
}
