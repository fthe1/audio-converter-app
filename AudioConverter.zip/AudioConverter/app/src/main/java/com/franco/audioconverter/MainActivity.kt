package com.franco.audioconverter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Ads.setup(this)
        setContent { AppTheme { App() } }
    }
}

// ---------------- Theme ----------------

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(
        primary = Color(0xFFFF7442),
        onPrimary = Color(0xFF1B0B03),
        primaryContainer = Color(0xFF3A2016),
        onPrimaryContainer = Color(0xFFFFDCCD),
        secondary = Color(0xFFA3A9FF),
        background = Color(0xFF0C0F17),
        surface = Color(0xFF0C0F17),
        onSurface = Color(0xFFECEEF4),
        onSurfaceVariant = Color(0xFF98A0B3),
        surfaceContainer = Color(0xFF151A26),
        surfaceContainerHigh = Color(0xFF1C2231),
        outlineVariant = Color(0xFF262D3E),
    ) else lightColorScheme(
        primary = Color(0xFFFF5B23),
        onPrimary = Color.White,
        primaryContainer = Color(0xFFFFE7DC),
        onPrimaryContainer = Color(0xFF5A1C05),
        secondary = Color(0xFF2E3192),
        background = Color(0xFFEEF0F5),
        surface = Color(0xFFEEF0F5),
        onSurface = Color(0xFF141824),
        onSurfaceVariant = Color(0xFF5E6577),
        surfaceContainer = Color.White,
        surfaceContainerHigh = Color(0xFFF4F5F9),
        outlineVariant = Color(0xFFDDE1EA),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

// ---------------- Root ----------------

@Composable
fun App(vm: MainViewModel = viewModel()) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var doc by rememberSaveable { mutableStateOf<String?>(null) }
    val activity = LocalContext.current as? Activity
    // One interstitial after every successful conversion.
    LaunchedEffect(vm.pendingAd) {
        if (vm.pendingAd) {
            vm.pendingAd = false
            activity?.let { Ads.show(it) }
        }
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0; doc = null },
                    icon = { Icon(Icons.Rounded.GraphicEq, null) }, label = { Text("تحويل") },
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1; doc = null },
                    icon = { Icon(Icons.Rounded.LibraryMusic, null) }, label = { Text("ملفاتي") },
                )
                NavigationBarItem(
                    selected = tab == 2, onClick = { tab = 2; doc = null },
                    icon = { Icon(Icons.Rounded.Settings, null) }, label = { Text("الإعدادات") },
                )
            }
        },
    ) { pad ->
        AnimatedContent(targetState = tab to doc, label = "tab") { (t, d) ->
            when {
                d != null -> DocScreen(d, pad, onBack = { doc = null })
                t == 0 -> ConvertScreen(vm, pad, onOpenFiles = { tab = 1 })
                t == 1 -> FilesScreen(vm, pad)
                else -> SettingsScreen(pad, onOpenDoc = { doc = it })
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Spacer(Modifier.height(28.dp))
    Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(4.dp))
    Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Spacer(Modifier.height(24.dp))
}

// ---------------- Convert screen ----------------

@Composable
fun ConvertScreen(vm: MainViewModel, pad: PaddingValues, onOpenFiles: () -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.onVideoPicked(uri)
    }
    val pick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }
    val running = vm.state is ConvertState.Running

    Column(
        Modifier
            .fillMaxSize()
            .padding(pad)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Header("استخرج الصوت من أي فيديو", "يتم كل شيء على هاتفك، بسرعة وبدون إنترنت")

        val v = vm.video
        when {
            vm.loadingVideo -> Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            v == null -> PickCard(pick)
            else -> VideoCard(v, enabled = !running, onChange = pick)
        }

        if (v != null && !vm.loadingVideo) {
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = vm.fileName,
                onValueChange = { vm.fileName = it },
                label = { Text("اسم الملف") },
                suffix = { Text(".m4a") },
                singleLine = true,
                enabled = !running && vm.state !is ConvertState.Done,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(20.dp))

            when (val s = vm.state) {
                is ConvertState.Running -> ProgressBlock(s.progress, vm::cancel)
                is ConvertState.Done -> DoneBlock(s.fileName, onOpenFiles, onNew = { vm.reset(); pick() })
                else -> {
                    if (s is ConvertState.Failed) ErrorText(s.message)
                    if (!v.hasAudio) ErrorText("هذا الفيديو لا يحتوي على صوت")
                    Button(
                        onClick = vm::convert,
                        enabled = v.hasAudio && vm.fileName.isNotBlank(),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                    ) {
                        Icon(Icons.Rounded.MusicNote, null)
                        Spacer(Modifier.width(8.dp))
                        Text("تحويل إلى صوت", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        } else if (vm.state is ConvertState.Failed) {
            Spacer(Modifier.height(16.dp))
            ErrorText((vm.state as ConvertState.Failed).message)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ErrorText(msg: String) {
    Text(
        msg, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier.padding(bottom = 12.dp),
    )
}

@Composable
private fun PickCard(onPick: () -> Unit) {
    Surface(
        onClick = onPick,
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.padding(vertical = 36.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            IconBubble(Icons.Rounded.VideoLibrary, 64)
            Spacer(Modifier.height(16.dp))
            Text("اختر فيديو من هاتفك", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "MP4 · MKV · MOV · 3GP وغيرها",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(20.dp))
            FilledTonalButton(onClick = onPick, shape = RoundedCornerShape(12.dp)) { Text("اختيار فيديو") }
        }
    }
}

@Composable
private fun VideoCard(v: VideoInfo, enabled: Boolean, onChange: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                contentAlignment = Alignment.Center,
            ) {
                if (v.thumb != null) Image(v.thumb, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                else Icon(Icons.Rounded.Movie, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(v.name, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text(
                    listOf(formatDuration(v.durationMs), formatSize(v.sizeBytes)).filter { it.isNotEmpty() }.joinToString("  ·  "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            TextButton(onClick = onChange, enabled = enabled) { Text("تغيير") }
        }
    }
}

@Composable
private fun ProgressBlock(progress: Int, onCancel: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("جارٍ استخراج الصوت…", style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text("$progress%", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { progress / 100f },
            strokeCap = StrokeCap.Round,
            modifier = Modifier.fillMaxWidth().height(8.dp),
        )
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onCancel, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("إلغاء") }
    }
}

@Composable
private fun DoneBlock(name: String, onOpenFiles: () -> Unit, onNew: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(44.dp))
            Spacer(Modifier.height(10.dp))
            Text(
                "تم الحفظ بنجاح", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                name, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onOpenFiles, shape = RoundedCornerShape(12.dp)) { Text("عرض الملفات") }
                OutlinedButton(onClick = onNew, shape = RoundedCornerShape(12.dp)) { Text("فيديو آخر") }
            }
        }
    }
}

@Composable
private fun IconBubble(icon: ImageVector, sizeDp: Int) {
    Box(
        Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size((sizeDp * 0.45f).dp))
    }
}

// ---------------- Files screen ----------------

@Composable
fun FilesScreen(vm: MainViewModel, pad: PaddingValues) {
    LaunchedEffect(Unit) { vm.refresh() }
    val ctx = LocalContext.current

    Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp)) {
        Header("ملفاتي", if (vm.files.isEmpty()) "الملفات الصوتية المحوّلة" else "${vm.files.size} ملف صوتي")
        if (vm.files.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(top = 48.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                IconBubble(Icons.Rounded.LibraryMusic, 72)
                Spacer(Modifier.height(16.dp))
                Text("لا توجد ملفات بعد", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "الملفات التي تحوّلها ستظهر هنا",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
            ) {
                items(vm.files, key = { it.uri.toString() }) { item ->
                    AudioRow(
                        item = item,
                        playing = vm.playingUri == item.uri,
                        progress = { vm.playProgress },
                        onToggle = { vm.togglePlay(item) },
                        onShare = { share(ctx, item) },
                        onDelete = { vm.delete(item) },
                    )
                }
            }
        }
    }
}

@Composable
private fun AudioRow(
    item: AudioItem,
    playing: Boolean,
    progress: () -> Float,
    onToggle: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Surface(
        onClick = onToggle,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(
            1.dp,
            if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(start = 12.dp, end = 4.dp, top = 12.dp, bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer,
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (playing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                        contentDescription = if (playing) "إيقاف" else "تشغيل",
                        tint = if (playing) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        item.name.removeSuffix(".m4a"),
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        listOf(formatDuration(item.durationMs), formatSize(item.sizeBytes), formatDate(item.dateMs))
                            .filter { it.isNotEmpty() }.joinToString("  ·  "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onShare) { Icon(Icons.Rounded.Share, "مشاركة") }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "المزيد") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("حذف") },
                            leadingIcon = { Icon(Icons.Rounded.DeleteOutline, null) },
                            onClick = { menu = false; onDelete() },
                        )
                    }
                }
            }
            if (playing) {
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = progress,
                    strokeCap = StrokeCap.Round,
                    modifier = Modifier.fillMaxWidth().padding(end = 8.dp).height(4.dp),
                )
            }
        }
    }
}

// ---------------- Helpers ----------------

private fun share(ctx: Context, item: AudioItem) {
    val send = Intent(Intent.ACTION_SEND).apply {
        type = "audio/mp4"
        putExtra(Intent.EXTRA_STREAM, item.shareUri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, "مشاركة الملف"))
}

fun formatDuration(ms: Long): String {
    if (ms <= 0) return ""
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%d:%02d", m, sec)
}

fun formatSize(bytes: Long): String = when {
    bytes <= 0 -> ""
    bytes < 1024 * 1024 -> String.format(Locale.US, "%d KB", bytes / 1024)
    else -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
}

private fun formatDate(ms: Long): String =
    if (ms <= 0) "" else SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ms))
